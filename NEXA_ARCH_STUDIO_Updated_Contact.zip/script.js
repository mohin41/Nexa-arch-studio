/* IMPORTANT: Replace these placeholders before publishing. WhatsApp: country code + number, digits only, no + or spaces. */
const CONFIG = {
  email: "mdmohsinfardin@gmail.com",
  whatsapp: "8801706574231"
};
const nav = document.getElementById('nav');
const menuBtn = document.getElementById('menuBtn');
menuBtn.addEventListener('click', () => {const open = nav.classList.toggle('open');menuBtn.setAttribute('aria-expanded', String(open));menuBtn.textContent = open ? '✕' : '☰';});
nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {nav.classList.remove('open');menuBtn.setAttribute('aria-expanded','false');menuBtn.textContent='☰';}));
document.getElementById('year').textContent = new Date().getFullYear();
const emailLink=document.getElementById('emailLink');
const waLink=document.getElementById('whatsappLink');
const floatWa=document.getElementById('floatingWhatsapp');
if(CONFIG.email){emailLink.textContent=CONFIG.email;emailLink.href='mailto:'+CONFIG.email;}
if(CONFIG.whatsapp){const url='https://wa.me/'+CONFIG.whatsapp;waLink.textContent='Chat with our studio';waLink.href=url;waLink.target='_blank';waLink.rel='noopener noreferrer';floatWa.href=url;floatWa.target='_blank';floatWa.rel='noopener noreferrer';}
const form=document.getElementById('quoteForm');
const status=document.getElementById('formStatus');
function inquiry(){if(!form.reportValidity())return null;const f=new FormData(form);return `New project inquiry — NEXA ARCH STUDIO\n\nName: ${f.get('name')}\nEmail: ${f.get('email')}\nProject type: ${f.get('type')}\nLocation: ${f.get('location')}\nDetails: ${f.get('details')}`;}
form.addEventListener('submit',e=>{e.preventDefault();const message=inquiry();if(!message)return;if(!CONFIG.email){status.textContent='Setup required: add your real business email in script.js before sending inquiries.';return;}window.location.href=`mailto:${CONFIG.email}?subject=${encodeURIComponent('Project inquiry — NEXA ARCH STUDIO')}&body=${encodeURIComponent(message)}`;status.textContent='Your email application should open with a prepared inquiry. Please press Send there.';});
document.getElementById('quoteWhatsapp').addEventListener('click',()=>{const message=inquiry();if(!message)return;if(!CONFIG.whatsapp){status.textContent='Setup required: add your real WhatsApp business number in script.js.';return;}window.open('https://wa.me/'+CONFIG.whatsapp+'?text='+encodeURIComponent(message),'_blank','noopener,noreferrer');status.textContent='WhatsApp should open with a prepared message. Please press Send there.';});
