# NEXA ARCH STUDIO — GitHub Pages Website

## Files
- index.html — website structure and content
- styles.css — responsive styling
- script.js — mobile menu, quote inquiry, contact buttons

## Before publishing
1. Contact details are already configured: mdmohsinfardin@gmail.com and WhatsApp +8801706574231.
2. WhatsApp must be digits only, with country code and no plus sign. Never use a stranger's number.
3. Portfolio graphics are abstract illustrative placeholders, NOT actual completed architectural projects. Replace them with licensed original renders when ready.
4. The quote form launches the visitor's email app or WhatsApp and requires them to press Send. It does NOT store submissions or send messages automatically.
5. The studio description is conceptual and does not claim licensed architecture/engineering services.

## Publish using Android
1. Extract ZIP with Android Files app.
2. Open github.com in Chrome, sign in, and create a PUBLIC repository named `nexa-arch-studio`.
3. Choose Add file → Upload files; upload `index.html`, `styles.css`, `script.js` to the ROOT of the repository, then Commit changes. Do not upload the outer folder only.
4. Open repository Settings → Pages → Build and deployment → Deploy from a branch → `main` → `/ (root)` → Save.
5. Wait for deployment. Website URL: `https://YOUR-USERNAME.github.io/nexa-arch-studio/`.
6. Test menu, quote form and WhatsApp button on mobile.

Note: GitHub Pages is public static hosting, not a backend or secure data collection service.
